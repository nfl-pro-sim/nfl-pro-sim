import { GameEngine } from './GameEngine.js';

window.addEventListener('DOMContentLoaded', () => {
    const game = new GameEngine();
    console.log("NFL Pro Sim 2025 Initialized");
});// JavaScript Document